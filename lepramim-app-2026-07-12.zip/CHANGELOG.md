# Changelog

## 0.4.7

- Atualiza o icone instalado do app com a nova logo enviada.
- Usa a nova marca tambem na splash screen e no topo da tela principal.
- Atualiza assets da Play Store com telas verticais novas e feature graphic nova.
- Atualiza copy da Play Store sem prometer Pix, mantendo pagamento via Google Play.

## 0.4.6

- Nova identidade visual premium em azul, verde e branco.
- Nova tela inicial com header em degrade, card de texto para audio, botao central de tocar, card de leitura assistida e barra inferior.
- Novo icone vetorial do app com livro, balao de fala e alto-falante verde.
- Adaptive Icon atualizado para Android 8+.
- Splash screen com logo, nome LePraMim e slogan "Leitura em voz alta".
- Tema ajustado com status bar azul, navigation bar branca, cards grandes e cantos arredondados.

## 0.4.5

- WhatsApp agora prioriza mensagens recebidas depois do ultimo separador de conversa, como "Hoje" ou data.
- Leitura do WhatsApp considera a caixa de digitacao para nao cortar a ultima mensagem visivel no rodape.
- Limita a fala do WhatsApp as 3 ultimas mensagens recebidas de texto.
- Remove emojis e reacoes da fala em conversas e notificacoes.
- Ignora midias, video, imagem, audio, figurinha, camera, play e textos de controles visuais.
- Evita repetir a mesma leitura do WhatsApp quando o usuario toca novamente no botao flutuante.
- Adiciona testes unitarios baseados em conversa real com mensagem antiga, video enviado e ultima mensagem recebida.

## 0.4.4

- Melhora a fala de conversas para soar mais humana e menos robotica.
- WhatsApp agora resume mensagens recebidas por pessoa quando possivel.
- Notificacoes de conversa agora falam primeiro o nome do app e organizam mensagens por remetente.
- Filtra descricoes de icones, botoes, camera, audio, emoji, figurinha, play e controles visuais.
- Adiciona formatacao generica para outros apps de conversa, como Telegram, SMS, Messenger e Instagram.
- Adiciona testes unitarios para resumo de conversa, varios remetentes e filtro de icones.

## 0.4.3

- Melhora leitura do WhatsApp para reconhecer conversa, ignorar texto digitado e priorizar mensagens recebidas.
- Corrige classificacao de mensagens enviadas longas para nao falar como recebidas.
- Melhora leitura generica em outros apps filtrando botoes comuns, campos de digitacao, status e rodape.
- Aumenta teste gratis para 60 leituras de tela e 10 leituras de imagem por dia.
- Remove botoes duplicados de assinatura da tela principal; Plus fica opcional em tela propria.
- Ajusta modo padrao para fala util sem introducoes artificiais em textos comuns.

## 0.4.2

- Hotfix de release: corrige fechamento ao abrir causado pela minificacao do ML Kit.
- Minificacao e reducao de recursos foram desativadas temporariamente no release ate validacao completa das regras R8.

## 0.4.1

- Leitura do WhatsApp refeita para priorizar mensagens recebidas.
- Mensagens enviadas pelo dono do celular nao sao lidas como conteudo principal.
- Horarios, botoes e textos de interface do WhatsApp sao filtrados.
- Notificacoes do WhatsApp falam "Mensagem de..." sem passar pelo explicador generico.
- Voz padrao ajustada para ritmo mais natural.
- Testes unitarios para conversa do WhatsApp.

## 0.4.0

- Onboarding com modo cuidador/familiar e modo usuário.
- Tela de configurações premium para leitura, voz, botão flutuante, segurança, cuidador e Plus.
- Tela LePraMim Plus com mensal, anual, benefícios e restaurar compra.
- Botão flutuante arrastável com posição salva.
- Toque simples para ler, toque duplo para repetir e segurar para parar.
- Leitura inteligente local com detecção de boleto, valor, data, consulta, entrega, código, senha, PIX, banco, link suspeito e golpe.
- Modo Seguro ligado por padrão.
- Preferências de voz, velocidade e tom.
- Camada `BillingRepository` e `EntitlementManager`.
- Backend preparado para validação de assinatura com Google Play Developer API.
- Testes unitários para leitura inteligente e limite do plano grátis.
- Documentação de Play Store, privacidade, acessibilidade, testes e release.
